import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-visualizador-de-gr-ficos',
  templateUrl: 'visualizador-de-gr-ficos.html'
})
export class VisualizadorDeGrFicosPage {

  constructor(public navCtrl: NavController) {
  }
  
}
